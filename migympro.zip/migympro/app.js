import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import { getAuth, signInWithEmailAndPassword, signOut, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";

// IMPORTANT: Replace this with your actual Firebase Config
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

async function secureFetch(endpoint, method = 'GET', body = null) {
  const user = auth.currentUser;
  if (!user) throw new Error("Not logged in");
  const token = await user.getIdToken(true); 
  const headers = { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' };
  const res = await fetch(`/api/${endpoint}`, { method, headers, body: body ? JSON.stringify(body) : null });
  if (!res.ok) {
    let errData = { error: 'Request failed' };
    try { errData = await res.json(); } catch(e) {}
    throw new Error(errData.error || `HTTP ${res.status}`);
  }
  return res.json();
}

const state = { role: 'guest', route: 'dashboard' };
const $ = (s, r=document) => r.querySelector(s);
const esc = s => String(s??'').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

function toast(msg, type='') {
  const t = document.createElement('div');
  t.className = `toast ${type}`;
  t.textContent = msg;
  $('#toast').appendChild(t);
  setTimeout(() => t.remove(), 3000);
}

$('#togglePwBtn').addEventListener('click', () => {
  const pw = $('#loginPw');
  pw.type = pw.type === 'password' ? 'text' : 'password';
});

$('#loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const email = e.target.email.value;
  const password = e.target.password.value;
  const btn = e.target.querySelector('button[type="submit"]');
  const errBox = $('#loginError');
  
  btn.disabled = true;
  btn.textContent = 'Signing in...';
  errBox.style.display = 'none';

  try {
    await signInWithEmailAndPassword(auth, email, password);
    // For demo, assign role based on email. In production, fetch role from API.
    if (email === 'cupncare@gmail.com') state.role = 'superadmin';
    else if (email.includes('gym')) state.role = 'gymowner';
    else state.role = 'member';
    
    $('#authRoot').style.display = 'none';
    $('#appRoot').style.display = 'grid';
    render();
  } catch (err) {
    errBox.textContent = err.message.replace('Firebase: ', '');
    errBox.style.display = 'block';
  } finally {
    btn.disabled = false;
    btn.textContent = 'Sign In';
  }
});

$('#btnLogout').addEventListener('click', () => {
  signOut(auth).then(() => {
    state.role = 'guest';
    $('#authRoot').style.display = 'flex';
    $('#appRoot').style.display = 'none';
    $('#loginForm').reset();
  });
});

onAuthStateChanged(auth, (user) => {
  if (!user) {
    $('#authRoot').style.display = 'flex';
    $('#appRoot').style.display = 'none';
  }
});

function renderNav() {
  const navMap = {
    superadmin: [{ id: 'dashboard', label: 'Platform' }],
    gymowner: [{ id: 'dashboard', label: 'Dashboard' }, { id: 'members', label: 'Members' }],
    member: [{ id: 'm-home', label: 'Home' }, { id: 'm-shop', label: 'Shop' }]
  };
  const list = navMap[state.role] || [];
  $('#nav').innerHTML = list.map(n => `<button class="ni ${state.route === n.id ? 'on' : ''}" data-nav="${n.id}"><span>${n.label}</span></button>`).join('');
  document.querySelectorAll('#nav .ni').forEach(btn => {
    btn.addEventListener('click', () => { state.route = btn.dataset.nav; render(); });
  });
}

function renderFoot() {
  if(!auth.currentUser) return;
  $('#sfoot').innerHTML = `<div class="av" style="width:32px;height:32px;font-size:12px;background:linear-gradient(135deg,#4d9dff,#3ddc97)">${auth.currentUser.email[0].toUpperCase()}</div><div class="who"><b>${esc(auth.currentUser.email.split('@')[0])}</b><span>${state.role}</span></div>`;
}

function statCard(lbl, val, color) {
  return `<div class="stat"><div class="ic" style="color:${color}"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/></svg></div><div><div class="lbl">${lbl}</div><div class="val">${val}</div></div></div>`;
}

const views = {
  dashboard: () => `<div class="grid g4">${statCard('Members', '8', '#3ddc97')}${statCard('Pending', '2', '#ffb340')}${statCard('Revenue', 'Rs. 1,200', '#c6ff3d')}${statCard('Face Enrolled', '5', '#4d9dff')}</div>`,
  members: () => `<div class="card"><div class="ch"><h3>Members Directory</h3><div class="sp"></div><button class="btn acc" onclick="toast('Feature coming soon')">+ Add Member</button></div><div class="tw"><table><tbody><tr><td><div class="cm"><div class="av" style="width:32px;height:32px;background:#555">MK</div><div><div class="nm">Mike K.</div><div class="em">mike@test.com</div></div></div></td><td>Monthly</td><td><span class="pill active">Active</span></td></tr></tbody></table></div></div>`,
  'm-home': () => `<div class="ban inf"><div class="ic"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg></div><div style="flex:1"><h3>Welcome to MiGym Secure</h3><p>Your account is in demo mode.</p></div></div><div class="grid g4">${statCard('Days Left', '30', '#c6ff3d')}${statCard('Plan', 'Monthly', '#4d9dff')}${statCard('Face ID', 'Active', '#3ddc97')}${statCard('BMI', '22.5', '#a78bfa')}</div>`
};

const VIEWMETA = { 'dashboard': { t: 'Dashboard', s: 'Overview' }, 'members': { t: 'Members', s: 'Directory' }, 'm-home': { t: 'My Gym', s: 'Overview' } };

function render() {
  renderNav(); renderFoot();
  const meta = VIEWMETA[state.route] || { t: 'Dashboard', s: '' };
  $('#pgTitle').textContent = meta.t;
  $('#pgSub').textContent = meta.s;
  const viewFn = views[state.route] || views.dashboard;
  $('#view').innerHTML = viewFn();
}

$('#btnRegGym').addEventListener('click', () => {
  $('#modalRoot').innerHTML = `
    <div class="ov" id="modalBg"><div class="modal lg"><div class="mh"><h3>Register Gym</h3><div class="sp"></div><button class="ib" id="closeModalBtn">✕</button></div>
    <form id="regGymForm"><div class="mb"><div class="fg">
      <div class="fl full"><label>Gym Name *</label><input class="inp" name="name" required></div>
      <div class="fl full"><label>Owner Email *</label><input class="inp" type="email" name="email" required></div>
      <div class="fl full"><label>Password *</label><input class="inp" type="password" name="password" required minlength="6"></div>
    </div>
    <div class="upi-box"><div class="upi-box-header">Platform Fee</div><div class="upi-amount">Rs. 500</div><div class="upi-id">Pay to: <strong>cupncare@upi</strong></div>
    <label class="paid-check" style="margin-top:16px"><input type="checkbox" required><span>I have completed the payment</span></label></div></div>
    <div class="mf"><button type="button" class="btn gho" id="cancelModalBtn">Cancel</button><button type="submit" class="btn acc">Submit</button></div></form></div></div>`;
  bindModalEvents('#regGymForm', 'gym/register');
});

$('#btnRegMember').addEventListener('click', () => {
  $('#modalRoot').innerHTML = `
    <div class="ov" id="modalBg"><div class="modal lg"><div class="mh"><h3>Register Member</h3><div class="sp"></div><button class="ib" id="closeModalBtn">✕</button></div>
    <form id="regMemberForm"><div class="mb"><div class="fg">
      <div class="fl full"><label>Full Name *</label><input class="inp" name="name" required></div>
      <div class="fl full"><label>Email *</label><input class="inp" type="email" name="email" required></div>
      <div class="fl full"><label>Password *</label><input class="inp" type="password" name="password" required minlength="6"></div>
      <div class="fl"><label>Weight (kg)</label><input class="inp" type="number" name="weight" value="70" required></div>
      <div class="fl"><label>Plan</label><select class="inp" name="plan"><option value="monthly">Monthly</option><option value="yearly">Yearly</option></select></div>
    </div>
    <div class="upi-box"><div class="upi-box-header">Payment</div><div class="upi-amount" id="memFee">Rs. 45</div>
    <label class="paid-check" style="margin-top:16px"><input type="checkbox" required><span>I agree to pay this amount</span></label></div></div>
    <div class="mf"><button type="button" class="btn gho" id="cancelModalBtn">Cancel</button><button type="submit" class="btn acc">Create Account</button></div></form></div></div>`;
  
  $('#regMemberForm [name="plan"]').addEventListener('change', (e) => {
    $('#memFee').textContent = e.target.value === 'monthly' ? 'Rs. 45' : 'Rs. 400';
  });
  bindModalEvents('#regMemberForm', 'member/register');
});

function bindModalEvents(formSelector, endpoint) {
  const closeFn = () => $('#modalRoot').innerHTML = '';
  $('#closeModalBtn')?.addEventListener('click', closeFn);
  $('#cancelModalBtn')?.addEventListener('click', closeFn);
  $('#modalBg')?.addEventListener('click', (e) => { if(e.target.id === 'modalBg') closeFn(); });

  $(formSelector).addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = e.target.querySelector('button[type="submit"]');
    btn.disabled = true;
    btn.textContent = 'Processing...';

    const fd = new FormData(e.target);
    const data = Object.fromEntries(fd.entries());
    data.weight = parseFloat(data.weight) || 70;

    try {
      await secureFetch(endpoint, 'POST', data);
      toast('Registration successful! Please sign in.');
      closeFn();
    } catch (err) {
      toast(err.message, 'err');
      btn.disabled = false;
      btn.textContent = 'Submit';
    }
  });
}