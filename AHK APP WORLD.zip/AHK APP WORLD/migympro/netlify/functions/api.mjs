import admin from 'firebase-admin';
import { z } from 'zod';

if (!admin.apps.length) {
  try {
    const serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT);
    admin.initializeApp({ credential: admin.credential.cert(serviceAccount) });
  } catch (error) { console.error('Firebase Init Error:', error); }
}
const db = admin.firestore();

const gymSchema = z.object({
  name: z.string().min(2).max(100),
  email: z.string().email(),
  password: z.string().min(6)
});

const memberSchema = z.object({
  name: z.string().min(2).max(100),
  email: z.string().email(),
  weight: z.number().min(30).max(300),
  plan: z.enum(['monthly', 'quarterly', 'half', 'yearly'])
});

export default async (req, context) => {
  const origin = req.headers.get('origin');
  const allowedOrigins = ['https://ahkenterprise.netlify.app', 'http://localhost:8888'];
  
  if (origin && !allowedOrigins.includes(origin) && !origin.includes('localhost')) {
    return new Response(JSON.stringify({ error: 'CORS blocked' }), { status: 403 });
  }

  const corsHeaders = {
    'Access-Control-Allow-Origin': origin || '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization'
  };

  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: corsHeaders });

  const authHeader = req.headers.get('authorization');
  if (!authHeader?.startsWith('Bearer ')) {
    return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: corsHeaders });
  }

  const token = authHeader.split('Bearer ')[1];
  let decodedToken;
  try {
    decodedToken = await admin.auth().verifyIdToken(token, true);
  } catch (err) {
    return new Response(JSON.stringify({ error: 'Invalid token' }), { status: 401, headers: corsHeaders });
  }

  const uid = decodedToken.uid;
  const url = new URL(req.url);
  const path = url.pathname.replace('/api/', '').replace(/\/$/, '');

  try {
    if (req.method === 'POST' && path === 'gym/register') {
      const body = await req.json();
      const validatedData = gymSchema.parse(body);
      const docRef = await db.collection('gyms').add({
        name: validatedData.name,
        email: validatedData.email,
        ownerUid: uid,
        status: 'pending_approval',
        createdAt: admin.firestore.FieldValue.serverTimestamp()
      });
      return new Response(JSON.stringify({ success: true, id: docRef.id }), { status: 200, headers: corsHeaders });
    }

    if (req.method === 'POST' && path === 'member/register') {
      const body = await req.json();
      const validatedData = memberSchema.parse(body);
      const docRef = await db.collection('members').add({
        ...validatedData,
        authUid: uid,
        status: 'active',
        createdAt: admin.firestore.FieldValue.serverTimestamp()
      });
      return new Response(JSON.stringify({ success: true, id: docRef.id }), { status: 200, headers: corsHeaders });
    }

    return new Response(JSON.stringify({ error: 'Route not found' }), { status: 404, headers: corsHeaders });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return new Response(JSON.stringify({ error: 'Invalid input', details: error.errors }), { status: 400, headers: corsHeaders });
    }
    return new Response(JSON.stringify({ error: 'Server error' }), { status: 500, headers: corsHeaders });
  }
};

export const config = { path: "/api/*" };