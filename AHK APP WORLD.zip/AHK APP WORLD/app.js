import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import {
  getAuth, GoogleAuthProvider, signInWithPopup,
  onAuthStateChanged, signOut as fbSignOut,
  setPersistence, browserLocalPersistence
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";

const firebaseConfig = {
  apiKey:            "AIzaSyDXG4MmHYKd5VRC3XZy4qOpcEfQV-iJDkY",
  authDomain:        "apponsale-c11f3.firebaseapp.com",
  projectId:         "apponsale-c11f3",
  storageBucket:     "apponsale-c11f3.firebasestorage.app",
  messagingSenderId: "701953325146",
  appId:             "1:701953325146:web:82d8dd70db61be07108063",
  measurementId:     "G-H3SWJ1ECME"
};

// ⚠️ Backend endpoints (Updated to singular 'admin-action')
const ADMIN_FN_URL = "/.netlify/functions/admin-action";
const OPEN_FN_URL  = "/open-app"; // Uses the redirect from netlify.toml

// No SUPERADMIN_EMAIL constant here. Verification is handled securely on the server.

const defaultLinks = [
  { name: "Cup N Care",         url: "cupncare/index.html",  visible: true },
  { name: "AHK Wellness",       url: "ahk/index.html",       visible: true },
  { name: "Abdul Hameed Kunhi", url: "ahk/index.html",       visible: true },
  { name: "Mi Gym App",         url: "migym/index.html",     visible: true },
  { name: "Profile Mi",         url: "profilemi/index.html", visible: true }
];

const isConfigured = !Object.values(firebaseConfig)
  .some(v => !v || String(v).includes('PASTE'));

let auth = null, provider = null;
if (isConfigured) {
  const fbApp = initializeApp(firebaseConfig);
  auth = getAuth(fbApp);
  setPersistence(auth, browserLocalPersistence).catch(console.error);
  provider = new GoogleAuthProvider();
  provider.addScope('email');
  provider.addScope('profile');
  provider.setCustomParameters({ prompt: 'select_account' });
} else {
  document.getElementById('configWarning').style.display = 'block';
}

const $ = id => document.getElementById(id);

async function callAdmin(action, payload = {}) {
  const user = auth && auth.currentUser;
  if (!user) { const e = new Error('Not signed in.'); e.status = 401; throw e; }
  
  const idToken = await user.getIdToken(true);
  const res = await fetch(ADMIN_FN_URL, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${idToken}` },
    body:    JSON.stringify({ action, ...payload })
  });
  
  let data = {};
  try { data = await res.json(); } catch {}
  
  if (!res.ok) {
    const e = new Error(data.error || `Request failed (${res.status})`);
    e.status = res.status;
    throw e;
  }
  return data;
}

// Fallback for demo mode (if Firebase config is missing)
const LocalStore = {
  key: 'ahkLinksData',
  read() {
    try {
      const raw = JSON.parse(localStorage.getItem(this.key) || 'null');
      if (Array.isArray(raw)) return raw;
    } catch {}
    return defaultLinks.map((d, i) => ({ id: String(i + 1), ...d }));
  },
  write(list) { localStorage.setItem(this.key, JSON.stringify(list)); }
};

const AuthManager = {
  async signIn() {
    if (!isConfigured) throw new Error("Firebase is not configured.");
    const res = await signInWithPopup(auth, provider);
    if (!res.user) { await fbSignOut(auth); throw new Error("Sign-in failed."); }
    return res.user;
  },
  async signOut() { if (isConfigured) await fbSignOut(auth); },
  onChange(cb)    { if (isConfigured) onAuthStateChanged(auth, cb); }
};

let adminAppsCache = [];
let refreshTimer = null;

function showLoginScreen() {
  $('authLoading').style.display         = 'none';
  $('authSection').style.display         = 'block';
  $('adminContentSection').style.display = 'none';
  $('authError').style.display           = 'none';
}

function showAdminPanel(user) {
  $('authLoading').style.display         = 'none';
  $('authSection').style.display         = 'none';
  $('adminContentSection').style.display = 'block';

  const fallbackAvatar = 'data:image/svg+xml;utf8,' + encodeURIComponent(
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">' +
    '<circle cx="50" cy="50" r="50" fill="#e62e3c"/>' +
    '<text x="50" y="58" text-anchor="middle" fill="#fff" font-size="42" font-family="Arial">A</text></svg>'
  );
  $('adminAvatar').src = user.photoURL || fallbackAvatar;
  $('adminName').textContent         = user.displayName || 'Admin';
  $('adminEmailDisplay').textContent = user.email || 'Admin';

  $('adminModal').style.display = 'flex';
  refreshAdminList();
  
  if (refreshTimer) clearInterval(refreshTimer);
  refreshTimer = setInterval(refreshAdminList, 5000);
}

async function handleAuthState(user) {
  if (!user) { showLoginScreen(); return; }

  $('authLoading').style.display = 'block';
  $('authSection').style.display = 'none';

  try {
    // Server is the sole authority for verifying if the user is the superadmin
    await callAdmin('whoami'); 
    showAdminPanel(user);
  } catch (e) {
    await AuthManager.signOut().catch(() => {});
    showLoginScreen();
    const el = $('authError');
    el.textContent = e.status === 403
      ? 'Access denied. This account is not authorized.'
      : 'Could not verify session. Please try again.';
    el.style.display = 'block';
  }
}

async function refreshAdminList() {
  try {
    if (isConfigured) {
      const data = await callAdmin('list');
      adminAppsCache = data.apps || [];
    } else {
      adminAppsCache = LocalStore.read().map(a => ({
        id: a.id, name: a.name, visible: !!a.visible, hasUrl: !!a.url
      }));
    }
    renderAdminList();
  } catch (e) {
    console.warn('List refresh failed:', e.message);
  }
}

function renderAdminList() {
  const list = $('adminLinksList');
  list.innerHTML = '';

  if (!adminAppsCache.length) {
    const empty = document.createElement('p');
    empty.className = 'empty-state';
    empty.textContent = 'No apps yet. Click "Seed Default Apps" below.';
    list.appendChild(empty);
    $('seedBtn').style.display = 'block';
    return;
  }
  $('seedBtn').style.display = 'none';

  adminAppsCache.forEach(link => {
    const item = document.createElement('div');
    item.className = 'admin-link-item' + (link.visible ? '' : ' hidden-link');

    const info = document.createElement('div');
    info.className = 'admin-link-info';
    const strong = document.createElement('strong');
    strong.textContent = link.name;
    const small = document.createElement('small');
    small.textContent = link.visible ? '● Visible' : '○ Hidden';
    info.append(strong, small);

    const editBtn = document.createElement('button');
    editBtn.className = 'action-btn edit-btn';
    editBtn.textContent = '✏️';
    editBtn.title = 'Edit URL';
    editBtn.addEventListener('click', () => handleEditUrl(link));

    const toggleBtn = document.createElement('button');
    toggleBtn.className = 'action-btn ' + (link.visible ? 'toggle-btn' : 'toggle-btn is-hidden');
    toggleBtn.textContent = link.visible ? '👁️' : '🙈';
    toggleBtn.title = link.visible ? 'Hide' : 'Show';
    toggleBtn.addEventListener('click', () => handleToggle(link));

    const delBtn = document.createElement('button');
    delBtn.className = 'action-btn delete-btn';
    delBtn.textContent = '🗑️';
    delBtn.title = 'Delete';
    delBtn.addEventListener('click', () => handleDelete(link));

    item.append(info, editBtn, toggleBtn, delBtn);
    list.appendChild(item);
  });
}

async function handleEditUrl(link) {
  try {
    let currentUrl = '';
    if (isConfigured) {
      const r = await callAdmin('get-url', { id: link.id });
      currentUrl = r.url || '';
    } else {
      const local = LocalStore.read().find(a => String(a.id) === String(link.id));
      currentUrl = local ? local.url : '';
    }
    const newUrl = prompt(`Edit URL for "${link.name}":`, currentUrl);
    if (newUrl === null) return;
    const trimmed = newUrl.trim();
    if (!trimmed || trimmed === currentUrl) return;

    if (isConfigured) await callAdmin('update-url', { id: link.id, url: trimmed });
    else {
      const list = LocalStore.read();
      const item = list.find(a => String(a.id) === String(link.id));
      if (item) { item.url = trimmed; LocalStore.write(list); }
    }
    refreshAdminList();
  } catch (e) { alert("Failed to update URL: " + e.message); }
}

async function handleToggle(link) {
  try {
    if (isConfigured) await callAdmin('toggle', { id: link.id, visible: !link.visible });
    else {
      const list = LocalStore.read();
      const item = list.find(a => String(a.id) === String(link.id));
      if (item) { item.visible = !item.visible; LocalStore.write(list); }
    }
    refreshAdminList();
  } catch (e) { alert("Failed to update: " + e.message); }
}

async function handleDelete(link) {
  if (!confirm(`Remove "${link.name}" from the list?`)) return;
  try {
    if (isConfigured) await callAdmin('delete', { id: link.id });
    else LocalStore.write(LocalStore.read().filter(a => String(a.id) !== String(link.id)));
    refreshAdminList();
  } catch (e) { alert("Failed to delete: " + e.message); }
}

async function handleAdd() {
  const name = $('newLinkName').value.trim();
  const url  = $('newLinkUrl').value.trim();
  if (!name || !url) return alert("Please fill in both fields.");
  
  const btn = $('addLinkBtn');
  const original = btn.textContent;
  btn.disabled = true; btn.textContent = '⏳ Adding...';
  
  try {
    if (isConfigured) await callAdmin('add', { name, url });
    else {
      const list = LocalStore.read();
      list.push({ id: Date.now().toString(), name, url, visible: true });
      LocalStore.write(list);
    }
    $('newLinkName').value = '';
    $('newLinkUrl').value  = '';
    refreshAdminList();
  } catch (e) {
    alert("Failed to add: " + e.message);
  } finally {
    btn.disabled = false; btn.textContent = original;
  }
}

async function handleReset() {
  if (!confirm("Reset all apps to defaults? This cannot be undone.")) return;
  const btn = $('resetBtn');
  const original = btn.textContent;
  btn.disabled = true; btn.textContent = '⏳ Resetting...';
  
  try {
    if (isConfigured) await callAdmin('reset');
    else LocalStore.write(defaultLinks.map((d, i) => ({ id: String(i + 1), ...d })));
    refreshAdminList();
  } catch (e) { alert("Reset failed: " + e.message); }
  finally { btn.disabled = false; btn.textContent = original; }
}

async function handleSeed() {
  const btn = $('seedBtn');
  const original = btn.textContent;
  btn.disabled = true; btn.textContent = '⏳ Seeding...';
  
  try {
    if (isConfigured) await callAdmin('seed');
    else LocalStore.write(defaultLinks.map((d, i) => ({ id: String(i + 1), ...d })));
    refreshAdminList();
  } catch (e) { alert("Seed failed: " + e.message); }
  finally { btn.disabled = false; btn.textContent = original; }
}

async function handleLogout() {
  if (refreshTimer) { clearInterval(refreshTimer); refreshTimer = null; }
  try { await AuthManager.signOut(); } catch {}
  showLoginScreen();
  $('adminModal').style.display = 'none';
}

async function handleGoogleSignIn() {
  $('authError').style.display   = 'none';
  $('authSection').style.display = 'none';
  $('authLoading').style.display = 'block';
  
  try {
    await AuthManager.signIn();
  } catch (e) {
    $('authLoading').style.display = 'none';
    $('authSection').style.display = 'block';
    const el = $('authError');
    el.textContent = e.message || "Sign-in failed.";
    el.style.display = 'block';
  }
}

async function testSecureApi() {
  const btn = $('testApiBtn');
  const original = btn.textContent;
  btn.disabled = true; btn.textContent = '⏳ Testing...';
  
  try {
    const data = await callAdmin('test');
    alert(`✅ Backend reachable\n\nMessage: ${data.message}\nAuthenticated as: ${data.email}`);
  } catch (e) {
    alert(`❌ Backend failed: ${e.message}`);
  } finally {
    btn.disabled = false; btn.textContent = original;
  }
}

function searchAndOpenApp() {
  const name = $('searchAppInput').value.trim();
  const errEl = $('searchError');

  if (!name) {
    errEl.textContent = 'Please enter an app name.';
    errEl.style.color = '#ff4d4d';
    errEl.style.display = 'block';
    return;
  }

  errEl.textContent = 'Opening...';
  errEl.style.color = '#a0aec0';
  errEl.style.display = 'block';

  // Server handles lookup + redirect via open-app.js
  window.location.href = `${OPEN_FN_URL}?name=${encodeURIComponent(name)}`;
}

(function handleUrlErrors() {
  const params = new URLSearchParams(window.location.search);
  const err    = params.get('err');
  if (!err) return;
  
  const messages = {
    notfound:  'App not found or is hidden.',
    ratelimit: 'Too many attempts. Please wait a minute.',
    invalid:   'Invalid app name.',
    server:    'Search failed. Please try again.'
  };
  
  document.getElementById('optionsModal').style.display = 'flex';
  const errEl = document.getElementById('searchError');
  errEl.textContent = messages[err] || 'Something went wrong.';
  errEl.style.color = '#ff4d4d';
  errEl.style.display = 'block';
  history.replaceState({}, '', '/');
})();

const optionsModal = $('optionsModal');
const adminModal   = $('adminModal');

$('openOptionsBtn').addEventListener('click', () => {
  optionsModal.style.display = 'flex';
  $('searchError').style.display = 'none';
  $('searchAppInput').value = '';
  setTimeout(() => $('searchAppInput').focus(), 100);
});
$('closeOptions').addEventListener('click', () => { optionsModal.style.display = 'none'; });
$('closeAdmin'  ).addEventListener('click', () => { adminModal.style.display   = 'none'; });
$('searchAppInput').addEventListener('keypress', e => { if (e.key === 'Enter') searchAndOpenApp(); });
$('searchOpenBtn' ).addEventListener('click', searchAndOpenApp);
$('googleSignInBtn').addEventListener('click', handleGoogleSignIn);
$('addLinkBtn').addEventListener('click', handleAdd);
$('resetBtn').addEventListener('click', handleReset);
$('seedBtn').addEventListener('click', handleSeed);
$('logoutBtn').addEventListener('click', handleLogout);
$('testApiBtn').addEventListener('click', testSecureApi);

let tapCount = 0, tapTimer;
$('secretLogo').addEventListener('click', () => {
  tapCount++;
  clearTimeout(tapTimer);
  tapTimer = setTimeout(() => { tapCount = 0; }, 2000);
  if (tapCount >= 5) { tapCount = 0; adminModal.style.display = 'flex'; }
});

window.addEventListener('click', e => {
  if (e.target === optionsModal) optionsModal.style.display = 'none';
  if (e.target === adminModal)   adminModal.style.display   = 'none';
});

(async function bootstrap() {
  if (isConfigured) AuthManager.onChange(handleAuthState);
  else showAdminPanel({ email: "demo@example.com", displayName: 'Demo Admin', photoURL: '' });
})();