/* deter.js — cosmetic only. Real security is server-side. */
(function () {
  'use strict';
  document.addEventListener('contextmenu', e => e.preventDefault());

  document.addEventListener('keydown', e => {
    const k = e.key;
    const blocked =
      k === 'F12' ||
      (e.ctrlKey && e.shiftKey && ['I','J','C','K'].includes(k.toUpperCase())) ||
      (e.metaKey && e.altKey   && ['I','J','C'].includes(k.toUpperCase())) ||
      (e.ctrlKey && k.toLowerCase() === 'u');
    if (blocked) { e.preventDefault(); e.stopPropagation(); }
  });

  const allowInField = t => t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA');

  document.addEventListener('copy', e => { if (!allowInField(e.target)) e.preventDefault(); });
  document.addEventListener('cut',  e => { if (!allowInField(e.target)) e.preventDefault(); });

  document.addEventListener('selectstart', e => {
    if (!allowInField(e.target)) e.preventDefault();
  });

  document.addEventListener('dragstart', e => e.preventDefault());
})();